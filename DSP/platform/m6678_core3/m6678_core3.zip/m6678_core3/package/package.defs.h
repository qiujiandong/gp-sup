/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-B21
 */

#ifndef m6678_core3__
#define m6678_core3__



#endif /* m6678_core3__ */ 
